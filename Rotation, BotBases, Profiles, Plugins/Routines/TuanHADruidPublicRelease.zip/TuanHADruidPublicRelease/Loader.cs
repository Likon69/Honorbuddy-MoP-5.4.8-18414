﻿// Credits to Phelon and Mirabis for making this work without using Assembly redirection.

using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Media;
using Styx;
using Styx.Common;
using Styx.CommonBot.Routines;
using Styx.TreeSharp;

namespace Loader
{
    public class Loader : CombatRoutine
    {
        private CombatRoutine CC;

        private readonly String[] Keep = new[] { "Loader.cs", "TuanHA_Combat_Routine.dll", "Settings", "User Settings", "Files", "Please Read - Installation Guide.txt", ".svn", "ChangeLog.txt" };

        public Loader()
        {

            #region SpecialEditionRuntime

            //string HonorbuddyDirectory = Utilities.AssemblyDirectory;
            //string pathSpecialEditionRuntime = HonorbuddyDirectory + @"\SpecialEditionRuntime.dll";
            //string urlSpecialEditionRuntime = "https://tuanha.sourcerepo.com/tuanha/SpecialEditionRuntime/SpecialEditionRuntime.dll";

            //if (File.Exists(pathSpecialEditionRuntime))
            //{
                //FileInfo f = new FileInfo(pathSpecialEditionRuntime);
                //long s1 = f.Length;

                //if (s1 != 647168)//Version 3.68
                //{
                    //File.Delete(pathSpecialEditionRuntime);

                    //if (MessageBox.Show(
                        //"This update require newer version of ALL TuanHA Combat Routines!" +
                        //Environment.NewLine +
                        //Environment.NewLine +
                        //"If ONE of the Special Edition in your folder not udpated, this Combat Routine will NOT work!" +
                        //Environment.NewLine +
                        //Environment.NewLine +
                        //"If you see a message - A new version of DNGuard Runtime library is needed to run this application. - Please update ALL your existing TuanHA Combat Routine!" +
                        //Environment.NewLine +
                        //Environment.NewLine +
                        //"Please click OK to visit the update guide.",
                        //"ALL TuanHA Combat Routines Need Update!",
                        //MessageBoxButtons.YesNo,
                        //MessageBoxIcon.Asterisk)
                        //== DialogResult.Yes)
                    //{
                        //System.Diagnostics.Process.Start("http://www.tuanha.biz/index.php/combat-routines/installation-guide#SpecialEditionRuntime");
                    //}
                //}
            //}

            //if (!File.Exists(pathSpecialEditionRuntime))
            //{
                //if (MessageBox.Show(
                     //"We need to download SpecialEditionRuntime.dll into folder" + HonorbuddyDirectory +
                    //Environment.NewLine +
                    //Environment.NewLine +
                    //"Please click OK to visit the download guide.",
                    //"TuanHA Druid Need An Update!",
                    //MessageBoxButtons.YesNo,
                    //MessageBoxIcon.Asterisk)
                    //== DialogResult.Yes)
                //{
                    //System.Diagnostics.Process.Start("http://www.tuanha.biz/index.php/combat-routines/installation-guide#SpecialEditionRuntime");
                //}
            //}

            #endregion

            string settingsDirectory = Path.Combine(Utilities.AssemblyDirectory, "Routines\\TuanHADruidPublicRelease");

            string path = settingsDirectory + @"\TuanHA_Combat_Routine.dll";

            if (!File.Exists(path))
            {
                MessageBox.Show("TuanHADruidPublicRelease is not installed correctly! Ensure files look like;" + 
                            Environment.NewLine + 
                            Environment.NewLine +
                            "<Honorbuddy>/Routines/TuanHADruidPublicRelease/Files/<.doc .jpg>" +
							Environment.NewLine +
                            "<Honorbuddy>/Routines/TuanHADruidPublicRelease/Preset/<XML Files>" +
							Environment.NewLine +
                            "<Honorbuddy>/Routines/TuanHADruidPublicRelease/Settings/<XML Files>" +
							Environment.NewLine +
                            "<Honorbuddy>/Routines/TuanHADruidPublicRelease/User Settings/<XML Files>" +
							Environment.NewLine +
                            "<Honorbuddy>/Routines/TuanHADruidPublicRelease/ChangeLog.txt" +
                            Environment.NewLine +
                            "<Honorbuddy>/Routines/TuanHADruidPublicRelease/Loader.cs" + 
                            Environment.NewLine +
                            "<Honorbuddy>/Routines/TuanHADruidPublicRelease/Please Read - Installation Guide.txt" +
                            Environment.NewLine +
                            "<Honorbuddy>/Routines/TuanHADruidPublicRelease/TuanHA_Combat_Routine.dll");
                return;
            }

            string pathTemp = settingsDirectory + @"\Files\TuanHA_Combat_Routine.dll.update";
            string pathTemp2 = settingsDirectory + @"\Files\TuanHA_Combat_Routine.dll";

            if (File.Exists(pathTemp))
            {
                if (File.Exists(path))
                {
                    try
                    {
                        //Logging.Write("Deleting " + path);
                        File.Delete(path);
                    }
                    catch (IOException ex)
                    {
                        Logging.Write(ex.ToString()); // Write error
                    }
                }

                try
                {
                    //Logging.Write("Moving " + pathTemp + " to " + path);
                    File.Move(pathTemp, pathTemp2);
                    File.Copy(pathTemp2, path);
                }
                catch (IOException ex)
                {
                    Logging.Write(ex.ToString()); // Write error
                }
            }

            bool removed = false;
            var DInfo = new DirectoryInfo(settingsDirectory);
            foreach (FileInfo file in DInfo.GetFiles())
            {
                if (!Keep.Contains(file.Name))
                {
                    removed = true;
                    Logging.Write("Removing " + file.Name + " from TuanHADruidPublicRelease directory");
                    file.Delete();
                }
            }
            //if (removed)
            //{
            //    MessageBox.Show("Removed unnecessary files from TuanHADruidPublicRelease directory, if TuanHADruidPublicRelease fails to work please restart honorbuddy.");
            //}

            try
            {
                Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");

				AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs e)
                {
                    try
                    {
                        AssemblyName requestedName = new AssemblyName(e.Name);
                        if (requestedName.Name == "Honorbuddy")
                        {
                            return Assembly.LoadFile(System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName);
                        }
						if (requestedName.Name == "GreyMagic")
                        {
                            return Assembly.LoadFile(Utilities.AssemblyDirectory + @"\GreyMagic.dll");
                        }
                        return null;
                    }
                    catch (System.Exception)
                    {
                        return null;
                    }
                };

                byte[] Bytes = File.ReadAllBytes(path);
                Assembly asm = Assembly.Load(Bytes);

                foreach (Type t in asm.GetTypes())
                {
                    if (t.IsSubclassOf(typeof(CombatRoutine)) && t.IsClass)
                    {
                        object obj = Activator.CreateInstance(t);
                        CC = (CombatRoutine)obj;
                    }
                }
            }
            catch (ThreadAbortException)
            {
                throw;
            }
            catch (ReflectionTypeLoadException ex)
            {
                var sb = new StringBuilder();
                foreach (Exception exSub in ex.LoaderExceptions)
                {
                    sb.AppendLine(exSub.Message);
                    if (exSub is FileNotFoundException)
                    {
                        var exFileNotFound = exSub as FileNotFoundException;
                        if (!string.IsNullOrEmpty(exFileNotFound.FusionLog))
                        {
                            sb.AppendLine("Fusion Log:");
                            sb.AppendLine(exFileNotFound.FusionLog);
                        }
                    }
                    sb.AppendLine();
                }
                string errorMessage = sb.ToString();
                //Display or log the error based on your application.
                Logging.Write(errorMessage);
            }
            catch (Exception e)
            {
                Logging.Write(Colors.DarkRed, "An error occured while loading TuanHADruidPublicRelease!");
                Logging.Write(e.ToString());
            }
        }

        #region Overrides of CombatRoutine

        public override string Name
        {
            get
            {
                return CC.Name;
            }
        }

        public override void Initialize()
        {
            CC.Initialize();
        }

        public override Composite CombatBehavior
        {
            get { return CC.CombatBehavior; }
        }

        public override Composite PreCombatBuffBehavior
        {
            get { return CC.PreCombatBuffBehavior; }
        }

        //public override Composite PullBehavior
        //{
        //    get { return CC.PullBehavior; }
        //}

        public override Composite RestBehavior
        {
            get { return CC.RestBehavior; }
        }
		
		public override Composite DeathBehavior
        {
            get { return CC.DeathBehavior; }
        }

        public override WoWClass Class
        {
            get
            {
                return WoWClass.Druid;
            }
        }

        public override void OnButtonPress()
        {
            CC.OnButtonPress();
        }

        public override void Pulse()
        {
            CC.Pulse();
        }

        public override bool WantButton
        {
            get { return true; }
        }

        #endregion
    }
}
